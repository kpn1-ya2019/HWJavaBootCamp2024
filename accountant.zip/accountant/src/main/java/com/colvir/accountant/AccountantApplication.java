package com.colvir.accountant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountantApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountantApplication.class, args);
	}

}
