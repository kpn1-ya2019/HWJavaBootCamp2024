package com.colvir.accountant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountantApplicationTests {

	@Test
	void contextLoads() {
	}

}
